#!/bin/bash

for i in {0..9}
    do
    	python run_learning.py --experiment 'final_results' --episodes 12000 --time_ep 20000 --num_config 8 --pop $i &
    done