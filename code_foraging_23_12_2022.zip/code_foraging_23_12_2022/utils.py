import yaml
import numpy as np
import pandas as pd
from scipy.special import zeta

def get_config(config, experiment):
    path = 'configurations/'+experiment+'/'+config
    with open(path, 'r') as f:
        config_dict = yaml.safe_load(f)
    return config_dict

def get_policy(results_path, config, agent, episode):
    
    memories = np.load(results_path + config + '/memories_pop_'+str(agent)+'_episode_'+str(episode)+'.npy')
    num_states = len(memories[0,0,:])
    
    y = []
    for state_index in range(num_states):
        y.append(memories[ 0, 0, state_index] / np.sum(memories[0, :,state_index]))
       
    return y
    
def walk_from_policy(policy, time_ep):
    '''Inputs:
    :time_ep (int): Number of steps
    :N (int): number of targets
    :L (int): world size
    .at (int/float): radius of the targets
    :policy (array): probability of staying in same direction at each time. If at some point
                     time > len(policy), the agent will rotate.
                     
     Ps(1) = 1 IS ALREADY CONSIDERED, DON'T INPUT IT!!!'''
    
     
    choices = [0]
    internal_clock = 0
    
    for t in range(time_ep-1):   
            
        if np.random.rand() > policy[internal_clock]:
            internal_clock = 0
            current_choice = 1
        else:
            internal_clock += 1
            current_choice = 0
            
        choices.append(current_choice)
            
    return choices


def powerlaw(beta, l):
    """ Normalized discrete powerlaw """
    return (1/zeta(beta+1, q=1)) * l ** (-1-beta)

def double_exp(parameters, l):
    """ Normalized discrete double exponential """
    d_int, d_ext, p = parameters
    gamma_int = 1/d_int
    gamma_ext = 1/d_ext
    return p * (1-np.exp(-gamma_int)) * np.exp(-gamma_int * (l-1)) + (1-p) * (1-np.exp(-gamma_ext)) * np.exp(-gamma_ext * (l-1))

def policy_from_distr(parameters, max_length, model='powerlaw'):
    
    policy = [1]
    for length in range(1, max_length+1):
        if model == 'powerlaw':
            policy.append(1 - powerlaw(parameters, length) / np.prod(policy))
        elif model == 'double_exp':
            policy.append(1 - double_exp(parameters, length) / np.prod(policy))
        
    policy = policy[1:]
    
    return policy

def get_opt(path, ls, model='powerlaw', run=''):
    
    df = pd.read_csv(path+'df'+run+'_'+model+'_kick_'+str(ls)+'.csv')
    filter_ = df['mean_reward'] == max(df['mean_reward'])
    
    if model == 'powerlaw':
        
        beta = float(df[filter_]['config/beta'])
        # rewards = np.load(path+'rewards_'+str(beta)+'.npy')
        return 0, 0, beta
        # return np.mean(rewards), np.std(rewards)/np.sqrt(len(rewards)), beta 
    
    elif model == 'double_exp':
        
        par = [float(df[filter_]['config/d_int']), float(df[filter_]['config/d_ext']), float(df[filter_]['config/p'])]
        # rewards = np.load(path+'rewards_'+str(par)+'.npy')
        return 0,0, par
        # return np.mean(rewards), np.std(rewards)/np.sqrt(len(rewards)), par 
     
        
# def get_opt(path, ls, N, L, model='powerlaw'):
    
#     results = np.load(path+'dict_'+model+'_rho_'+str(np.round(N/L**2,3))+'.npy', allow_pickle=True).item()
#     all_keys = []
#     rwds = []
#     for key, value in results.items():
#         if model == 'powerlaw':
#             if eval(key)[1] == ls:
#                 all_keys.append(eval(key)[0])
#                 rwds.append(np.mean(value))
#         if model == 'double_exp':
#             if eval(key)[3] == ls:
#                 all_keys.append(eval(key)[:3])
#                 rwds.append(np.mean(value))
    
#     max_reward = max(rwds)
#     index_max = np.argwhere(np.array(rwds) == max_reward)[0][0]
    
#     return max_reward, all_keys[index_max]
