from sys import argv, stdout
import argparse
from utils import get_config
import numpy as np
import pathlib

from env_notfly import TargetEnv
from forager import Forager

def get_args(argv):
    """
    Passes the arguments from the runfile to the main file or passes the default values to the main file.
    Returns a namespace object that makes each element callable by args.name.
    Args:
        argv  (list) list of arguments that are passed through with a --name

    Returns:
        args  (namespace) namespace of all arguments passed through
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--experiment', type=str, default='final_results', help='type of experiment')        
    parser.add_argument('--episodes', type=int, default=12000, help='number of episodes')
    parser.add_argument('--time_ep', type=int, default=3000, help='time steps per episode')
    parser.add_argument('--pop', type=int, default=10, help='population id')
    parser.add_argument('--num_config', type=int, default=8, help='number of the configuration file')
    args = parser.parse_args(argv)
    return args

if __name__ == "__main__":
    # get the experiment name, the configuration file name.
    args = get_args(argv[1:])
    EXPERIMENT = args.experiment
    EPISODES = args.episodes
    TIME_EP = args.time_ep
    POP = args.pop
    NUM_CONFIG = args.num_config
    
    CONFIG = 'exp_'+str(NUM_CONFIG)
    print(EXPERIMENT, CONFIG)


    # path of the results folder
    results_path = 'results/'+EXPERIMENT+'/'+CONFIG+'/'
    pathlib.Path(results_path).mkdir(parents=True, exist_ok=True)
    
    # load the configuration file
    config = get_config(CONFIG+'.cfg', EXPERIMENT)
    
    #Environment's parameters
    N = config['NUM_TARGETS']
    L = config['WORLD_SIZE'] 
    at = config['at']
    TAU = config['TAU']
    ls = config['ls']
    NUM_AGENTS = config['NUM_AGENTS']
    
    #Forager's parameters
    VISUAL_CONE = (np.pi / 180) * config['VISUAL_CONE']
    VISUAL_RADIUS = config['VISUAL_RADIUS']
    NUM_ACTIONS = config['NUM_ACTIONS']
    STATE_SPACE = [np.linspace(0, config['MAX_STEP_L']-1, config['NUM_BINS']), np.arange(1), np.arange(1)]
    
    NUM_STATES = np.prod([len(i) for i in STATE_SPACE])
    
    # Learning_parameters
    GAMMA = config['GAMMA']
    ETA_GLOW = config['ETA_GLOW']
    
    if config['PI_INIT'] == 0.5:
        INITIAL_DISTR = None
    elif config['PI_INIT'] == 0.99:
        INITIAL_DISTR = []
        for percept in range(NUM_STATES):
            INITIAL_DISTR.append([0.99, 0.01])
    
    if config['ls'] == 'None':
        DESTRUCTIVE = True
        print('Destructive targets, there is no kick')
    else:
        DESTRUCTIVE = False
        
    #initialize record of performance
    rewards = np.zeros((NUM_AGENTS, EPISODES))
    pos_agents = np.zeros((NUM_AGENTS, EPISODES, TIME_EP, 2))
    choices_agents = np.zeros((NUM_AGENTS, EPISODES, TIME_EP))
    targets = np.zeros((EPISODES, N, 2))
    agent_memories = np.zeros((NUM_AGENTS, NUM_ACTIONS, int(np.prod(np.array([len(i) for i in STATE_SPACE])))))
    percept_statistics = np.zeros((EPISODES, NUM_STATES))
    rewarded_percepts = np.zeros((EPISODES, NUM_STATES))
    rewarded_actions = np.zeros((EPISODES, NUM_ACTIONS))
    
    
    #initialize environment
    env = TargetEnv(Nt=N, L=L, at=at, ls=ls, tau=TAU, num_agents=NUM_AGENTS, destructive = DESTRUCTIVE)
    
    #initialize agents
    agents = []
    for ag in range(NUM_AGENTS):
        agents.append(Forager(visual_cone=VISUAL_CONE,
                                  visual_radius=VISUAL_RADIUS,
                                  state_space=STATE_SPACE,
                                  num_actions=NUM_ACTIONS,
                                  gamma=GAMMA,
                                  eta_glow_damping=ETA_GLOW,
                                  initial_prob_distr=INITIAL_DISTR))            
    
    for e in range(EPISODES):
        
        env.init_env()
        for i in range(NUM_AGENTS):
            agents[i].agent_state = 0
            agents[i].reset_g()
        
        #store target positions
        targets[e, :, :] = env.target_positions.clone()
        
        for t in range(TIME_EP):
            
            for i in range(NUM_AGENTS):
                
                pos_agents[i, e, t, :] = env.positions[i].clone()    
                
                if t == 0 or env.kicked[i]:
                    #do one step with random direction (no learning in this step)
                    env.update_pos(1, agent_index=i)
                    #check boundary conditions
                    env.check_bc(agent_index=i)
                    #reset counter (l=1)
                    agents[i].agent_state = 0
                    #set kicked value to false again
                    env.kicked[i] = 0
                    #set values to store in array for this time step
                    reward = 0
                    action = 1
                else:
                    #get perception
                    if NUM_AGENTS > 1:
                        visual_perception = env.get_state(i, agents[i].visual_cone, agents[i].visual_radius)
                    else:
                        visual_perception = [0,0]
                    state = agents[i].get_state(visual_perception)
                    
                    #decide
                    action = agents[i].deliberate(state)
                    
                    #act (update counter)
                    agents[i].act(action)
                    
                    #update positions
                    env.update_pos(action, agent_index=i)
                    #check if target was found + kick if it is
                    reward = env.check_encounter(agent_index=i)
                    if reward == 1:
                        rewarded_percepts[e, agents[i].percept_preprocess(state)] += 1
                        rewarded_actions[e, action] += 1
                        
                    #check boundary conditions
                    env.check_bc(agent_index=i)
                    #learn
                    agents[i].learn(reward)
                    
                    
                    #store info
                    percept_statistics[e, agents[i].percept_preprocess(state)] += 1
                    
                    
                # Save info
                rewards[i, e] += reward
                choices_agents[i, e, t] = action
        
        if (e+1)%500 == 0:
            #save h matrices of all agents at this stage of the learning process
            for i in range(NUM_AGENTS):
                agent_memories[i] = agents[i].h_matrix
            np.save(results_path+'memories_pop_'+str(POP)+'_episode_'+str(e+1)+'.npy', agent_memories)
        
            np.save(results_path+'rewards_pop_'+str(POP)+'.npy', rewards[:,:(e+1)])
            np.save(results_path+'percept_statistics_pop_'+str(POP)+'.npy', percept_statistics[:(e+1),:])
            np.save(results_path+'choices_pop_'+str(POP)+'.npy', choices_agents[:,:(e+1),:])
            np.save(results_path+'rewarded_percepts_pop_'+str(POP)+'.npy', rewarded_percepts[:(e+1),:])
            np.save(results_path+'rewarded_actions_pop_'+str(POP)+'.npy', rewarded_actions[:(e+1),:])
            
            print('\n', CONFIG, 'gamma:', GAMMA, 'eta', ETA_GLOW ,'pop', POP, 'Reward (avg last 500 ep), ', np.mean(rewards[0][(e+1-500):(e+1)]) )
            stdout.flush()
        
    np.save(results_path+'rewards_pop_'+str(POP)+'.npy', rewards)
    np.save(results_path+'pos_agents_pop_'+str(POP)+'.npy', pos_agents)
    np.save(results_path+'choices_pop_'+str(POP)+'.npy', choices_agents)
    np.save(results_path+'target_positions_pop_'+str(POP)+'.npy', targets)
    np.save(results_path+'percept_statistics_pop_'+str(POP)+'.npy', percept_statistics)
    np.save(results_path+'rewarded_percepts_pop_'+str(POP)+'.npy', rewarded_percepts)
    np.save(results_path+'rewarded_actions_pop_'+str(POP)+'.npy', rewarded_actions)
            